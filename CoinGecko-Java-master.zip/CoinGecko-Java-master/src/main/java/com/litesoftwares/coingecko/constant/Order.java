package com.litesoftwares.coingecko.constant;

public class Order {
    public static String GECKO_ASC =  "gecko_asc";
    public static String GECKO_DESC =  "gecko_desc";
    public static String MARKET_CAP_ASC =  "market_cap_asc";
    public static String MARKET_CAP_DESC =  "market_cap_desc";
    public static String VOLUME_ASC =  "volume_asc";
    public static String VOLUME_DESC =  "volume_desc";
    public static String COIN_NAME_ASC =  "coin_name_asc";
    public static String COIN_NAME_DESC =  "coin_name_desc";
    public static String PRICE_ASC =  "price_asc";
    public static String PRICE_DESC =  "price_desc";
    public static String HOUR_24_ASC =  "h24_change_asc";
    public static String HOUR_24_DESC =  "h24_change_desc";
    public static String TRUST_SCORE_DESC = "trust_score_desc";
}
